GYASI JIMXY STORE - ANDROID APP SOURCE

This is a simple Android WebView app that opens:
https://gyesijimxy-jxlg.mydukeshop.com

HOW TO BUILD THE APK
1. Install Android Studio on a computer.
2. Open the GyasiJimxyStore folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

The app requires an internet connection. The store handles its own catalogue, orders and checkout.
This folder is Android source code, not a compiled APK. It has not yet been built or tested on a device.
